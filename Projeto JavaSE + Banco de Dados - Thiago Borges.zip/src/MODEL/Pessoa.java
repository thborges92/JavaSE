package MODEL;

public class Pessoa {

    String nome, telefone;
    int id;

}
